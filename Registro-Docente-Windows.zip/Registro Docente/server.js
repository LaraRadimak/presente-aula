const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFile } = require('child_process');
const root = __dirname;
const port = Number(process.env.PORT || 4173);
const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.webmanifest':'application/manifest+json; charset=utf-8','.png':'image/png'};
http.createServer((req,res)=>{
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url,'http://localhost').pathname); } catch { res.writeHead(400).end(); return; }
  const filename = pathname==='/'?'index.html':pathname.slice(1);
  if(!/^[\w.-]+$/.test(filename)){res.writeHead(404).end();return}
  const full=path.join(root,filename);
  fs.readFile(full,(err,data)=>{if(err){res.writeHead(404).end('No encontrado');return}res.writeHead(200,{'Content-Type':types[path.extname(filename)]||'application/octet-stream','Cache-Control':'no-store','Access-Control-Allow-Origin':'*'});res.end(data)});
}).listen(port,'0.0.0.0',()=>{
  console.log(`\nRegistro Docente está disponible en: http://localhost:${port}`);
  const ips=Object.values(os.networkInterfaces()).flat().filter(x=>x.family==='IPv4'&&!x.internal).map(x=>x.address);
  for(const ip of ips)console.log(`Para usarlo en el celular (misma red): http://${ip}:${port}`);
  console.log('\nDejá esta ventana abierta mientras usás la aplicación. Cerrala con Ctrl+C.\n');
  if(process.platform==='win32')execFile('cmd',['/c','start',`http://localhost:${port}`]);
});
